<?php
/**
 * Displaying Footer.
 * @package Ultimate Ecommerce Shop
 */
?>
<?php
	get_template_part( 'template-parts/footer/footer', 'widgets' );
	
	get_template_part( 'template-parts/footer/site', 'info' );
?>

<?php wp_footer(); ?>

</body>
</html>
<?php
/**
 * Displays Site info
 */
?>

<div class="copyright-wrapper">
	<div class="inner">
        <div class="copyright">
           <p><?php echo esc_html(get_theme_mod('ultimate_ecommerce_shop_footer_copy',__('Education WordPress Theme By','ultimate-ecommerce-shop'))); ?> <?php ultimate_ecommerce_shop_credit(); ?></p>
        </div>
        <div class="clear"></div>
    </div>
</div>